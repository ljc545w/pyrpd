#-*-coding: utf-8 -*-
from .wechat import WeChat

__all__ = [
    "WeChat",
]